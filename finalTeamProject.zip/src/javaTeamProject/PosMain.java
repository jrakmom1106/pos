package javaTeamProject;

public class PosMain {
	
	
	
   public static void main(String[] args) {
      new PosFrame();

}
   
}